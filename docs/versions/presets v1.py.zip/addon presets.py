bl_info = {
    "name": "Presets de dimensions",
    "author": "Celtmen",
    "version": (1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Celtmen",
    "description": "Automatically configures dimensions for thumbnails, banners, PDP",
    "category": "Render",
}

import bpy

# Liste des presets sociaux
social_presets = [
    ("YOUTUBE_THUMB", "Miniature YouTube", "1280x720"),
    ("TWITTER_BANNER", "Bannière Twitter", "1500x500"),
    ("PROFILE_PIC", "PP", "500x500"),
    ("INSTAGRAM_POST", "Post Instagram", "1080x1080"),
    ("FACEBOOK_COVER", "Couverture Facebook", "820x312")
]

class SOCIAL_PT_Panel(bpy.types.Panel):
    bl_label = "Presets"
    bl_idname = "SOCIAL_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Celtmen'

    def draw(self, context):
        layout = self.layout
        layout.label(text="Choisis un preset:")
        for preset_id, preset_name, size in social_presets:
            op = layout.operator("social.set_dimensions", text=preset_name)
            op.preset = preset_id

class SOCIAL_OT_SetDimensions(bpy.types.Operator):
    bl_idname = "social.set_dimensions"
    bl_label = "Set Social Dimensions"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        cam = scene.camera

        # Définir les dimensions en fonction du preset
        if self.preset == "YOUTUBE_THUMB":
            width, height = 1280, 720
        elif self.preset == "TWITTER_BANNER":
            width, height = 1500, 500
        elif self.preset == "PROFILE_PIC":
            width, height = 500, 500
        elif self.preset == "INSTAGRAM_POST":
            width, height = 1080, 1080
        elif self.preset == "FACEBOOK_COVER":
            width, height = 820, 312
        else:
            self.report({'WARNING'}, "Preset inconnu")
            return {'CANCELLED'}

        # Appliquer au rendu
        scene.render.resolution_x = width
        scene.render.resolution_y = height
        scene.render.resolution_percentage = 100

        # Ajuster la caméra orthographique si elle existe
        if cam and cam.type == 'CAMERA':
            cam.data.type = 'ORTHO'
            cam.data.ortho_scale = max(width, height) / 100.0

        self.report({'INFO'}, f"Dimensions définies: {width}x{height}")
        return {'FINISHED'}

classes = [SOCIAL_PT_Panel, SOCIAL_OT_SetDimensions]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()