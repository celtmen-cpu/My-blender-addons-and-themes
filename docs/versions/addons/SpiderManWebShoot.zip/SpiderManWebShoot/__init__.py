if "bpy" in locals():
    import importlib
    importlib.reload(spidermanwebshoot)
else:
    from . import spidermanwebshoot

import bpy
import mathutils
import os
import typing


def menu_func(self, context):
    self.layout.operator(spidermanwebshoot.SpiderManWebShoot_OT_SpiderManWebShoot.bl_idname)
            
classes = [
    spidermanwebshoot.SpiderManWebShoot_OT_SpiderManWebShoot,
]
            
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.NODE_MT_add.append(menu_func)
            
def unregister():
    bpy.types.NODE_MT_add.remove(menu_func)
    for cls in classes:
        bpy.utils.unregister_class(cls)
            
if __name__ == "__main__":
    register()
