import bpy
import mathutils
import os
import typing



def spidermanwebshoot_2_node_group(node_tree_names: dict[typing.Callable, str]):
    """Initialize SpiderManWebShoot node group"""
    spidermanwebshoot_2 = bpy.data.node_groups.new(type='GeometryNodeTree', name="SpiderManWebShoot")

    spidermanwebshoot_2.color_tag = 'NONE'
    spidermanwebshoot_2.description = ""
    spidermanwebshoot_2.default_group_node_width = 140
    spidermanwebshoot_2.is_modifier = True
    spidermanwebshoot_2.show_modifier_manage_panel = True

    # spidermanwebshoot_2 interface

    # Socket Geometry
    geometry_socket = spidermanwebshoot_2.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    geometry_socket.default_input = 'VALUE'
    geometry_socket.structure_type = 'AUTO'

    # Socket Geometry
    geometry_socket_1 = spidermanwebshoot_2.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    geometry_socket_1.default_input = 'VALUE'
    geometry_socket_1.structure_type = 'AUTO'

    # Socket target
    target_socket = spidermanwebshoot_2.interface.new_socket(name="target", in_out='INPUT', socket_type='NodeSocketObject')
    target_socket.attribute_domain = 'POINT'
    target_socket.default_input = 'VALUE'
    target_socket.structure_type = 'AUTO'
    target_socket.optional_label = True

    # Socket main collection
    main_collection_socket = spidermanwebshoot_2.interface.new_socket(name="main collection", in_out='INPUT', socket_type='NodeSocketCollection')
    main_collection_socket.attribute_domain = 'POINT'
    main_collection_socket.default_input = 'VALUE'
    main_collection_socket.structure_type = 'AUTO'

    # Socket shooter
    shooter_socket = spidermanwebshoot_2.interface.new_socket(name="shooter", in_out='INPUT', socket_type='NodeSocketObject')
    shooter_socket.attribute_domain = 'POINT'
    shooter_socket.default_input = 'VALUE'
    shooter_socket.structure_type = 'AUTO'
    shooter_socket.optional_label = True

    # Socket distance
    distance_socket = spidermanwebshoot_2.interface.new_socket(name="distance", in_out='INPUT', socket_type='NodeSocketFloat')
    distance_socket.default_value = 0.5
    distance_socket.min_value = -10000.0
    distance_socket.max_value = 10000.0
    distance_socket.subtype = 'NONE'
    distance_socket.attribute_domain = 'POINT'
    distance_socket.default_input = 'VALUE'
    distance_socket.structure_type = 'AUTO'

    # Initialize spidermanwebshoot_2 nodes

    # Node Instance on Points
    instance_on_points = spidermanwebshoot_2.nodes.new("GeometryNodeInstanceOnPoints")
    instance_on_points.name = "Instance on Points"
    # Selection
    instance_on_points.inputs[1].default_value = True
    # Pick Instance
    instance_on_points.inputs[3].default_value = False
    # Instance Index
    instance_on_points.inputs[4].default_value = 0
    # Rotation
    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
    # Scale
    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)

    # Node Quadratic Bézier
    quadratic_b_zier = spidermanwebshoot_2.nodes.new("GeometryNodeCurveQuadraticBezier")
    quadratic_b_zier.name = "Quadratic Bézier"
    # Resolution
    quadratic_b_zier.inputs[0].default_value = 3
    # Start
    quadratic_b_zier.inputs[1].default_value = (-1.0, 0.0, 0.0)
    # Middle
    quadratic_b_zier.inputs[2].default_value = (0.0, 2.0, 0.0)
    # End
    quadratic_b_zier.inputs[3].default_value = (1.0, -2.799999713897705, -2.1999998092651367)

    # Node Realize Instances
    realize_instances = spidermanwebshoot_2.nodes.new("GeometryNodeRealizeInstances")
    realize_instances.name = "Realize Instances"
    realize_instances.realize_to_point_domain = False
    # Selection
    realize_instances.inputs[1].default_value = True
    # Realize All
    realize_instances.inputs[2].default_value = True
    # Depth
    realize_instances.inputs[3].default_value = 0

    # Node Set Position
    set_position = spidermanwebshoot_2.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    # Offset
    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)

    # Node Endpoint Selection
    endpoint_selection = spidermanwebshoot_2.nodes.new("GeometryNodeCurveEndpointSelection")
    endpoint_selection.name = "Endpoint Selection"
    # Start Size
    endpoint_selection.inputs[0].default_value = 1
    # End Size
    endpoint_selection.inputs[1].default_value = 1

    # Node Object Info
    object_info = spidermanwebshoot_2.nodes.new("GeometryNodeObjectInfo")
    object_info.name = "Object Info"
    object_info.transform_space = 'RELATIVE'
    # As Instance
    object_info.inputs[1].default_value = False

    # Node Vector Math
    vector_math = spidermanwebshoot_2.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'ADD'

    # Node Points.001
    points_001 = spidermanwebshoot_2.nodes.new("GeometryNodePoints")
    points_001.name = "Points.001"
    # Count
    points_001.inputs[0].default_value = 15
    # Radius
    points_001.inputs[2].default_value = 0.10000000149011612

    # Node Random Value
    random_value = spidermanwebshoot_2.nodes.new("FunctionNodeRandomValue")
    random_value.name = "Random Value"
    random_value.data_type = 'FLOAT_VECTOR'
    # Min
    random_value.inputs[0].default_value = (-1.0, 0.0, -1.0)
    # Max
    random_value.inputs[1].default_value = (1.0, 1.0, 1.0)
    # ID
    random_value.inputs[7].default_value = 0
    # Seed
    random_value.inputs[8].default_value = 0

    # Node Vector Math.001
    vector_math_001 = spidermanwebshoot_2.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'SCALE'

    # Node Set Position.001
    set_position_001 = spidermanwebshoot_2.nodes.new("GeometryNodeSetPosition")
    set_position_001.name = "Set Position.001"
    # Selection
    set_position_001.inputs[1].default_value = True
    # Offset
    set_position_001.inputs[3].default_value = (0.0, 0.0, 0.0)

    # Node Geometry Proximity
    geometry_proximity = spidermanwebshoot_2.nodes.new("GeometryNodeProximity")
    geometry_proximity.name = "Geometry Proximity"
    geometry_proximity.target_element = 'FACES'
    # Group ID
    geometry_proximity.inputs[1].default_value = 0
    # Source Position
    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
    # Sample Group ID
    geometry_proximity.inputs[3].default_value = 0

    # Node Collection Info
    collection_info = spidermanwebshoot_2.nodes.new("GeometryNodeCollectionInfo")
    collection_info.name = "Collection Info"
    collection_info.transform_space = 'RELATIVE'
    # Separate Children
    collection_info.inputs[1].default_value = False
    # Reset Children
    collection_info.inputs[2].default_value = False

    # Node Realize Instances.001
    realize_instances_001 = spidermanwebshoot_2.nodes.new("GeometryNodeRealizeInstances")
    realize_instances_001.name = "Realize Instances.001"
    realize_instances_001.realize_to_point_domain = False
    # Selection
    realize_instances_001.inputs[1].default_value = True
    # Realize All
    realize_instances_001.inputs[2].default_value = True
    # Depth
    realize_instances_001.inputs[3].default_value = 0

    # Node Object Info.002
    object_info_002 = spidermanwebshoot_2.nodes.new("GeometryNodeObjectInfo")
    object_info_002.name = "Object Info.002"
    object_info_002.transform_space = 'RELATIVE'
    # As Instance
    object_info_002.inputs[1].default_value = False

    # Node Object Info.003
    object_info_003 = spidermanwebshoot_2.nodes.new("GeometryNodeObjectInfo")
    object_info_003.name = "Object Info.003"
    object_info_003.transform_space = 'RELATIVE'
    # As Instance
    object_info_003.inputs[1].default_value = False

    # Node Curve Line
    curve_line = spidermanwebshoot_2.nodes.new("GeometryNodeCurvePrimitiveLine")
    curve_line.name = "Curve Line"
    curve_line.mode = 'POINTS'

    # Node Frame.002
    frame_002 = spidermanwebshoot_2.nodes.new("NodeFrame")
    frame_002.name = "Frame.002"
    frame_002.label_size = 20
    frame_002.shrink = True

    # Node Curve to Mesh
    curve_to_mesh = spidermanwebshoot_2.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh.name = "Curve to Mesh"
    # Scale
    curve_to_mesh.inputs[2].default_value = 0.0010000000474974513
    # Fill Caps
    curve_to_mesh.inputs[3].default_value = True

    # Node Join Geometry
    join_geometry = spidermanwebshoot_2.nodes.new("GeometryNodeJoinGeometry")
    join_geometry.name = "Join Geometry"

    # Node Curve to Mesh.001
    curve_to_mesh_001 = spidermanwebshoot_2.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh_001.name = "Curve to Mesh.001"
    # Scale
    curve_to_mesh_001.inputs[2].default_value = 0.0010000000474974513
    # Fill Caps
    curve_to_mesh_001.inputs[3].default_value = True

    # Node Curve Circle
    curve_circle = spidermanwebshoot_2.nodes.new("GeometryNodeCurvePrimitiveCircle")
    curve_circle.name = "Curve Circle"
    curve_circle.mode = 'RADIUS'
    # Resolution
    curve_circle.inputs[0].default_value = 32
    # Radius
    curve_circle.inputs[4].default_value = 1.0

    # Node Set Position.002
    set_position_002 = spidermanwebshoot_2.nodes.new("GeometryNodeSetPosition")
    set_position_002.name = "Set Position.002"
    # Selection
    set_position_002.inputs[1].default_value = True
    # Position
    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)

    # Node Noise Texture
    noise_texture = spidermanwebshoot_2.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    noise_texture.noise_type = 'FBM'
    noise_texture.normalize = True
    # Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    # Scale
    noise_texture.inputs[2].default_value = 20.0
    # Detail
    noise_texture.inputs[3].default_value = 15.0
    # Roughness
    noise_texture.inputs[4].default_value = 0.5
    # Lacunarity
    noise_texture.inputs[5].default_value = 2.0
    # Distortion
    noise_texture.inputs[8].default_value = 0.0

    # Node Vector Math.002
    vector_math_002 = spidermanwebshoot_2.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'MULTIPLY'
    # Vector_001
    vector_math_002.inputs[1].default_value = (1.0, 1.0, 1.0)

    # Node Resample Curve
    resample_curve = spidermanwebshoot_2.nodes.new("GeometryNodeResampleCurve")
    resample_curve.name = "Resample Curve"
    resample_curve.keep_last_segment = True
    # Selection
    resample_curve.inputs[1].default_value = True
    # Mode
    resample_curve.inputs[2].default_value = 'Count'
    # Count
    resample_curve.inputs[3].default_value = 200
    # Length
    resample_curve.inputs[4].default_value = 0.10000000149011612

    # Node Frame
    frame = spidermanwebshoot_2.nodes.new("NodeFrame")
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    # Node Frame.001
    frame_001 = spidermanwebshoot_2.nodes.new("NodeFrame")
    frame_001.name = "Frame.001"
    frame_001.label_size = 20
    frame_001.shrink = True

    # Node Group Output
    group_output = spidermanwebshoot_2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    # Node Vector Math.003
    vector_math_003 = spidermanwebshoot_2.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'SUBTRACT'

    # Node Group Input
    group_input = spidermanwebshoot_2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    # Node Math
    math = spidermanwebshoot_2.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'FLOOR'
    math.use_clamp = False

    # Node Combine XYZ
    combine_xyz = spidermanwebshoot_2.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"

    # Node Separate XYZ
    separate_xyz = spidermanwebshoot_2.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"

    # Node Separate XYZ.001
    separate_xyz_001 = spidermanwebshoot_2.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz_001.name = "Separate XYZ.001"

    # Node Mix
    mix = spidermanwebshoot_2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'
    # Factor_Float
    mix.inputs[0].default_value = 0.5

    # Node Frame.003
    frame_003 = spidermanwebshoot_2.nodes.new("NodeFrame")
    frame_003.name = "Frame.003"
    frame_003.label_size = 20
    frame_003.shrink = True

    # Node Group Input.001
    group_input_001 = spidermanwebshoot_2.nodes.new("NodeGroupInput")
    group_input_001.name = "Group Input.001"

    # Node Group Input.002
    group_input_002 = spidermanwebshoot_2.nodes.new("NodeGroupInput")
    group_input_002.name = "Group Input.002"

    # Node Geometry Input
    geometry_input = spidermanwebshoot_2.nodes.new("GeometryNodeGroup")
    geometry_input.name = "Geometry Input"
    # Finding linked library node group
    for node_group in bpy.data.node_groups:
        if (
            node_group.name == "Geometry Input"
            and node_group.bl_idname == 'GeometryNodeTree'
        ):
            geometry_input.node_tree = node_group
    if geometry_input.node_tree is None:
        print("Couldn't find node group Geometry Input, failing")
        return
    # Socket_6
    geometry_input.inputs[1].default_value = 'Object'
    # Socket_4
    geometry_input.inputs[4].default_value = False
    # Socket_5
    geometry_input.inputs[5].default_value = True
    # Socket_1
    geometry_input.inputs[6].default_value = False

    # Set parents
    spidermanwebshoot_2.nodes["Instance on Points"].parent = spidermanwebshoot_2.nodes["Frame.003"]
    spidermanwebshoot_2.nodes["Quadratic Bézier"].parent = spidermanwebshoot_2.nodes["Frame.003"]
    spidermanwebshoot_2.nodes["Realize Instances"].parent = spidermanwebshoot_2.nodes["Frame.003"]
    spidermanwebshoot_2.nodes["Set Position"].parent = spidermanwebshoot_2.nodes["Frame.003"]
    spidermanwebshoot_2.nodes["Endpoint Selection"].parent = spidermanwebshoot_2.nodes["Frame.003"]
    spidermanwebshoot_2.nodes["Object Info"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Vector Math"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Points.001"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Random Value"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Vector Math.001"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Set Position.001"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Geometry Proximity"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Collection Info"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Realize Instances.001"].parent = spidermanwebshoot_2.nodes["Frame.002"]
    spidermanwebshoot_2.nodes["Object Info.002"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Object Info.003"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Curve Line"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Curve to Mesh"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Curve Circle"].parent = spidermanwebshoot_2.nodes["Frame"]
    spidermanwebshoot_2.nodes["Set Position.002"].parent = spidermanwebshoot_2.nodes["Frame"]
    spidermanwebshoot_2.nodes["Noise Texture"].parent = spidermanwebshoot_2.nodes["Frame"]
    spidermanwebshoot_2.nodes["Vector Math.002"].parent = spidermanwebshoot_2.nodes["Frame"]
    spidermanwebshoot_2.nodes["Resample Curve"].parent = spidermanwebshoot_2.nodes["Frame"]
    spidermanwebshoot_2.nodes["Vector Math.003"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Group Input"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Math"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Combine XYZ"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Separate XYZ"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Separate XYZ.001"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Mix"].parent = spidermanwebshoot_2.nodes["Frame.001"]
    spidermanwebshoot_2.nodes["Group Input.002"].parent = spidermanwebshoot_2.nodes["Frame.002"]

    # Set locations
    spidermanwebshoot_2.nodes["Instance on Points"].location = (248.4527587890625, -101.89339447021484)
    spidermanwebshoot_2.nodes["Quadratic Bézier"].location = (29.9332275390625, -217.35740661621094)
    spidermanwebshoot_2.nodes["Realize Instances"].location = (470.357421875, -57.603912353515625)
    spidermanwebshoot_2.nodes["Set Position"].location = (704.1455078125, -30.14611053466797)
    spidermanwebshoot_2.nodes["Endpoint Selection"].location = (444.1563720703125, -244.50050354003906)
    spidermanwebshoot_2.nodes["Object Info"].location = (90.887939453125, -46.73743438720703)
    spidermanwebshoot_2.nodes["Vector Math"].location = (386.0457458496094, -56.42859649658203)
    spidermanwebshoot_2.nodes["Points.001"].location = (647.8790283203125, -32.602569580078125)
    spidermanwebshoot_2.nodes["Random Value"].location = (30.03924560546875, -301.50811767578125)
    spidermanwebshoot_2.nodes["Vector Math.001"].location = (313.1790771484375, -333.7669982910156)
    spidermanwebshoot_2.nodes["Set Position.001"].location = (1219.362548828125, -29.90216064453125)
    spidermanwebshoot_2.nodes["Geometry Proximity"].location = (973.6430053710938, -140.39524841308594)
    spidermanwebshoot_2.nodes["Collection Info"].location = (579.4117431640625, -417.2214660644531)
    spidermanwebshoot_2.nodes["Realize Instances.001"].location = (771.1336669921875, -226.90200805664062)
    spidermanwebshoot_2.nodes["Object Info.002"].location = (29.968994140625, -43.72724914550781)
    spidermanwebshoot_2.nodes["Object Info.003"].location = (178.6748046875, -279.044677734375)
    spidermanwebshoot_2.nodes["Curve Line"].location = (1595.77099609375, -70.59333801269531)
    spidermanwebshoot_2.nodes["Frame.002"].location = (-846.0, -34.5)
    spidermanwebshoot_2.nodes["Curve to Mesh"].location = (2030.9853515625, -78.306396484375)
    spidermanwebshoot_2.nodes["Join Geometry"].location = (3509.04833984375, 468.6653747558594)
    spidermanwebshoot_2.nodes["Curve to Mesh.001"].location = (2314.369140625, 106.40263366699219)
    spidermanwebshoot_2.nodes["Curve Circle"].location = (29.7587890625, -223.2236328125)
    spidermanwebshoot_2.nodes["Set Position.002"].location = (344.87060546875, -29.9017333984375)
    spidermanwebshoot_2.nodes["Noise Texture"].location = (800.84814453125, -153.4534912109375)
    spidermanwebshoot_2.nodes["Vector Math.002"].location = (455.23779296875, -352.5888671875)
    spidermanwebshoot_2.nodes["Resample Curve"].location = (580.0283203125, -121.697265625)
    spidermanwebshoot_2.nodes["Frame"].location = (2116.5, -1087.5)
    spidermanwebshoot_2.nodes["Frame.001"].location = (2652.5, 106.0)
    spidermanwebshoot_2.nodes["Group Output"].location = (3933.46484375, 645.4599609375)
    spidermanwebshoot_2.nodes["Vector Math.003"].location = (859.400146484375, -30.159378051757812)
    spidermanwebshoot_2.nodes["Group Input"].location = (818.026611328125, -606.8875122070312)
    spidermanwebshoot_2.nodes["Math"].location = (1156.66796875, -588.2335205078125)
    spidermanwebshoot_2.nodes["Combine XYZ"].location = (1613.07177734375, -442.371337890625)
    spidermanwebshoot_2.nodes["Separate XYZ"].location = (1399.00341796875, -679.3760986328125)
    spidermanwebshoot_2.nodes["Separate XYZ.001"].location = (1298.981689453125, -922.7713012695312)
    spidermanwebshoot_2.nodes["Mix"].location = (1597.4580078125, -720.1292724609375)
    spidermanwebshoot_2.nodes["Frame.003"].location = (1167.5, 22.0)
    spidermanwebshoot_2.nodes["Group Input.001"].location = (2501.083740234375, -286.04425048828125)
    spidermanwebshoot_2.nodes["Group Input.002"].location = (266.12506103515625, -537.7316284179688)
    spidermanwebshoot_2.nodes["Geometry Input"].location = (2944.439208984375, 653.9910888671875)

    # Set dimensions
    spidermanwebshoot_2.nodes["Instance on Points"].width  = 140.0
    spidermanwebshoot_2.nodes["Instance on Points"].height = 100.0

    spidermanwebshoot_2.nodes["Quadratic Bézier"].width  = 140.0
    spidermanwebshoot_2.nodes["Quadratic Bézier"].height = 100.0

    spidermanwebshoot_2.nodes["Realize Instances"].width  = 140.0
    spidermanwebshoot_2.nodes["Realize Instances"].height = 100.0

    spidermanwebshoot_2.nodes["Set Position"].width  = 140.0
    spidermanwebshoot_2.nodes["Set Position"].height = 100.0

    spidermanwebshoot_2.nodes["Endpoint Selection"].width  = 140.0
    spidermanwebshoot_2.nodes["Endpoint Selection"].height = 100.0

    spidermanwebshoot_2.nodes["Object Info"].width  = 140.0
    spidermanwebshoot_2.nodes["Object Info"].height = 100.0

    spidermanwebshoot_2.nodes["Vector Math"].width  = 140.0
    spidermanwebshoot_2.nodes["Vector Math"].height = 100.0

    spidermanwebshoot_2.nodes["Points.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Points.001"].height = 100.0

    spidermanwebshoot_2.nodes["Random Value"].width  = 140.0
    spidermanwebshoot_2.nodes["Random Value"].height = 100.0

    spidermanwebshoot_2.nodes["Vector Math.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Vector Math.001"].height = 100.0

    spidermanwebshoot_2.nodes["Set Position.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Set Position.001"].height = 100.0

    spidermanwebshoot_2.nodes["Geometry Proximity"].width  = 140.0
    spidermanwebshoot_2.nodes["Geometry Proximity"].height = 100.0

    spidermanwebshoot_2.nodes["Collection Info"].width  = 140.0
    spidermanwebshoot_2.nodes["Collection Info"].height = 100.0

    spidermanwebshoot_2.nodes["Realize Instances.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Realize Instances.001"].height = 100.0

    spidermanwebshoot_2.nodes["Object Info.002"].width  = 140.0
    spidermanwebshoot_2.nodes["Object Info.002"].height = 100.0

    spidermanwebshoot_2.nodes["Object Info.003"].width  = 140.0
    spidermanwebshoot_2.nodes["Object Info.003"].height = 100.0

    spidermanwebshoot_2.nodes["Curve Line"].width  = 140.0
    spidermanwebshoot_2.nodes["Curve Line"].height = 100.0

    spidermanwebshoot_2.nodes["Frame.002"].width  = 1389.5
    spidermanwebshoot_2.nodes["Frame.002"].height = 705.5

    spidermanwebshoot_2.nodes["Curve to Mesh"].width  = 140.0
    spidermanwebshoot_2.nodes["Curve to Mesh"].height = 100.0

    spidermanwebshoot_2.nodes["Join Geometry"].width  = 140.0
    spidermanwebshoot_2.nodes["Join Geometry"].height = 100.0

    spidermanwebshoot_2.nodes["Curve to Mesh.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Curve to Mesh.001"].height = 100.0

    spidermanwebshoot_2.nodes["Curve Circle"].width  = 140.0
    spidermanwebshoot_2.nodes["Curve Circle"].height = 100.0

    spidermanwebshoot_2.nodes["Set Position.002"].width  = 140.0
    spidermanwebshoot_2.nodes["Set Position.002"].height = 100.0

    spidermanwebshoot_2.nodes["Noise Texture"].width  = 145.0
    spidermanwebshoot_2.nodes["Noise Texture"].height = 100.0

    spidermanwebshoot_2.nodes["Vector Math.002"].width  = 140.0
    spidermanwebshoot_2.nodes["Vector Math.002"].height = 100.0

    spidermanwebshoot_2.nodes["Resample Curve"].width  = 140.0
    spidermanwebshoot_2.nodes["Resample Curve"].height = 100.0

    spidermanwebshoot_2.nodes["Frame"].width  = 976.0
    spidermanwebshoot_2.nodes["Frame"].height = 568.5

    spidermanwebshoot_2.nodes["Frame.001"].width  = 2201.0
    spidermanwebshoot_2.nodes["Frame.001"].height = 1072.0

    spidermanwebshoot_2.nodes["Group Output"].width  = 140.0
    spidermanwebshoot_2.nodes["Group Output"].height = 100.0

    spidermanwebshoot_2.nodes["Vector Math.003"].width  = 140.0
    spidermanwebshoot_2.nodes["Vector Math.003"].height = 100.0

    spidermanwebshoot_2.nodes["Group Input"].width  = 140.0
    spidermanwebshoot_2.nodes["Group Input"].height = 100.0

    spidermanwebshoot_2.nodes["Math"].width  = 140.0
    spidermanwebshoot_2.nodes["Math"].height = 100.0

    spidermanwebshoot_2.nodes["Combine XYZ"].width  = 140.0
    spidermanwebshoot_2.nodes["Combine XYZ"].height = 100.0

    spidermanwebshoot_2.nodes["Separate XYZ"].width  = 140.0
    spidermanwebshoot_2.nodes["Separate XYZ"].height = 100.0

    spidermanwebshoot_2.nodes["Separate XYZ.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Separate XYZ.001"].height = 100.0

    spidermanwebshoot_2.nodes["Mix"].width  = 140.0
    spidermanwebshoot_2.nodes["Mix"].height = 100.0

    spidermanwebshoot_2.nodes["Frame.003"].width  = 874.0
    spidermanwebshoot_2.nodes["Frame.003"].height = 574.5

    spidermanwebshoot_2.nodes["Group Input.001"].width  = 140.0
    spidermanwebshoot_2.nodes["Group Input.001"].height = 100.0

    spidermanwebshoot_2.nodes["Group Input.002"].width  = 140.0
    spidermanwebshoot_2.nodes["Group Input.002"].height = 100.0

    spidermanwebshoot_2.nodes["Geometry Input"].width  = 170.0
    spidermanwebshoot_2.nodes["Geometry Input"].height = 100.0


    # Initialize spidermanwebshoot_2 links

    # instance_on_points.Instances -> realize_instances.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Instance on Points"].outputs[0],
        spidermanwebshoot_2.nodes["Realize Instances"].inputs[0]
    )
    # realize_instances.Geometry -> set_position.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Realize Instances"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position"].inputs[0]
    )
    # endpoint_selection.Selection -> set_position.Selection
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Endpoint Selection"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position"].inputs[1]
    )
    # quadratic_b_zier.Curve -> instance_on_points.Instance
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Quadratic Bézier"].outputs[0],
        spidermanwebshoot_2.nodes["Instance on Points"].inputs[2]
    )
    # object_info.Location -> vector_math.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info"].outputs[1],
        spidermanwebshoot_2.nodes["Vector Math"].inputs[0]
    )
    # vector_math.Vector -> points_001.Position
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Vector Math"].outputs[0],
        spidermanwebshoot_2.nodes["Points.001"].inputs[1]
    )
    # set_position_001.Geometry -> instance_on_points.Points
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Set Position.001"].outputs[0],
        spidermanwebshoot_2.nodes["Instance on Points"].inputs[0]
    )
    # random_value.Value -> vector_math_001.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Random Value"].outputs[0],
        spidermanwebshoot_2.nodes["Vector Math.001"].inputs[0]
    )
    # vector_math_001.Vector -> vector_math.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Vector Math.001"].outputs[0],
        spidermanwebshoot_2.nodes["Vector Math"].inputs[1]
    )
    # object_info.Scale -> vector_math_001.Scale
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info"].outputs[3],
        spidermanwebshoot_2.nodes["Vector Math.001"].inputs[3]
    )
    # points_001.Points -> set_position_001.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Points.001"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position.001"].inputs[0]
    )
    # geometry_proximity.Position -> set_position_001.Position
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Geometry Proximity"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position.001"].inputs[2]
    )
    # collection_info.Instances -> realize_instances_001.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Collection Info"].outputs[0],
        spidermanwebshoot_2.nodes["Realize Instances.001"].inputs[0]
    )
    # realize_instances_001.Geometry -> geometry_proximity.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Realize Instances.001"].outputs[0],
        spidermanwebshoot_2.nodes["Geometry Proximity"].inputs[0]
    )
    # curve_line.Curve -> curve_to_mesh.Curve
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Curve Line"].outputs[0],
        spidermanwebshoot_2.nodes["Curve to Mesh"].inputs[0]
    )
    # curve_to_mesh_001.Mesh -> join_geometry.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Curve to Mesh.001"].outputs[0],
        spidermanwebshoot_2.nodes["Join Geometry"].inputs[0]
    )
    # curve_circle.Curve -> resample_curve.Curve
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Curve Circle"].outputs[0],
        spidermanwebshoot_2.nodes["Resample Curve"].inputs[0]
    )
    # resample_curve.Curve -> set_position_002.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Resample Curve"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position.002"].inputs[0]
    )
    # noise_texture.Color -> vector_math_002.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Noise Texture"].outputs[1],
        spidermanwebshoot_2.nodes["Vector Math.002"].inputs[0]
    )
    # vector_math_002.Vector -> set_position_002.Offset
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Vector Math.002"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position.002"].inputs[3]
    )
    # set_position_002.Geometry -> curve_to_mesh.Profile Curve
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Set Position.002"].outputs[0],
        spidermanwebshoot_2.nodes["Curve to Mesh"].inputs[1]
    )
    # set_position_002.Geometry -> curve_to_mesh_001.Profile Curve
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Set Position.002"].outputs[0],
        spidermanwebshoot_2.nodes["Curve to Mesh.001"].inputs[1]
    )
    # join_geometry.Geometry -> group_output.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Join Geometry"].outputs[0],
        spidermanwebshoot_2.nodes["Group Output"].inputs[0]
    )
    # object_info_003.Location -> curve_line.Start
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info.003"].outputs[1],
        spidermanwebshoot_2.nodes["Curve Line"].inputs[0]
    )
    # math.Value -> combine_xyz.X
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Math"].outputs[0],
        spidermanwebshoot_2.nodes["Combine XYZ"].inputs[0]
    )
    # math.Value -> combine_xyz.Y
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Math"].outputs[0],
        spidermanwebshoot_2.nodes["Combine XYZ"].inputs[1]
    )
    # combine_xyz.Vector -> vector_math_003.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Combine XYZ"].outputs[0],
        spidermanwebshoot_2.nodes["Vector Math.003"].inputs[1]
    )
    # vector_math_003.Vector -> curve_line.End
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Vector Math.003"].outputs[0],
        spidermanwebshoot_2.nodes["Curve Line"].inputs[1]
    )
    # object_info_002.Location -> vector_math_003.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info.002"].outputs[1],
        spidermanwebshoot_2.nodes["Vector Math.003"].inputs[0]
    )
    # object_info_003.Location -> separate_xyz.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info.003"].outputs[1],
        spidermanwebshoot_2.nodes["Separate XYZ"].inputs[0]
    )
    # object_info_002.Location -> separate_xyz_001.Vector
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Object Info.002"].outputs[1],
        spidermanwebshoot_2.nodes["Separate XYZ.001"].inputs[0]
    )
    # separate_xyz_001.Z -> mix.A
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Separate XYZ.001"].outputs[2],
        spidermanwebshoot_2.nodes["Mix"].inputs[2]
    )
    # separate_xyz.Z -> mix.B
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Separate XYZ"].outputs[2],
        spidermanwebshoot_2.nodes["Mix"].inputs[3]
    )
    # mix.Result -> combine_xyz.Z
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Mix"].outputs[0],
        spidermanwebshoot_2.nodes["Combine XYZ"].inputs[2]
    )
    # set_position.Geometry -> curve_to_mesh_001.Curve
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Set Position"].outputs[0],
        spidermanwebshoot_2.nodes["Curve to Mesh.001"].inputs[0]
    )
    # vector_math_003.Vector -> set_position.Position
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Vector Math.003"].outputs[0],
        spidermanwebshoot_2.nodes["Set Position"].inputs[2]
    )
    # group_input.distance -> math.Value
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input"].outputs[3],
        spidermanwebshoot_2.nodes["Math"].inputs[0]
    )
    # group_input_001.shooter -> object_info_003.Object
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input.001"].outputs[2],
        spidermanwebshoot_2.nodes["Object Info.003"].inputs[0]
    )
    # group_input_001.target -> object_info_002.Object
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input.001"].outputs[0],
        spidermanwebshoot_2.nodes["Object Info.002"].inputs[0]
    )
    # group_input_002.target -> object_info.Object
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input.002"].outputs[0],
        spidermanwebshoot_2.nodes["Object Info"].inputs[0]
    )
    # group_input_002.main collection -> collection_info.Collection
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input.002"].outputs[1],
        spidermanwebshoot_2.nodes["Collection Info"].inputs[0]
    )
    # group_input_001.shooter -> geometry_input.Object
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Group Input.001"].outputs[2],
        spidermanwebshoot_2.nodes["Geometry Input"].inputs[2]
    )
    # geometry_input.Geometry -> join_geometry.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Geometry Input"].outputs[0],
        spidermanwebshoot_2.nodes["Join Geometry"].inputs[0]
    )
    # curve_to_mesh.Mesh -> join_geometry.Geometry
    spidermanwebshoot_2.links.new(
        spidermanwebshoot_2.nodes["Curve to Mesh"].outputs[0],
        spidermanwebshoot_2.nodes["Join Geometry"].inputs[0]
    )

    return spidermanwebshoot_2

class SpiderManWebShoot_OT_SpiderManWebShoot(bpy.types.Operator):
    bl_idname = "spidermanwebshoot.spidermanwebshoot_1"
    bl_label = "SpiderManWebShoot"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def execute(self, context: bpy.types.Context):
        # Import node groups from Blender essentials library
        datafiles_path = bpy.utils.system_resource('DATAFILES')
        lib_relpath = "assets/nodes/geometry_nodes_essentials.blend"
        lib_path = os.path.join(datafiles_path, lib_relpath)
        with bpy.data.libraries.load(lib_path, link=True)  as (data_src, data_dst):
        	data_dst.node_groups = []
        	if "Geometry Input" in data_src.node_groups:
        		data_dst.node_groups.append("Geometry Input")
        

        # Maps node tree creation functions to the node tree 
        # name, such that we don't recreate node trees unnecessarily
        node_tree_names : dict[typing.Callable, str] = {}

        spidermanwebshoot_2 = spidermanwebshoot_2_node_group(node_tree_names)
        node_tree_names[spidermanwebshoot_2_node_group] = spidermanwebshoot_2.name

        return {'FINISHED'}
        
